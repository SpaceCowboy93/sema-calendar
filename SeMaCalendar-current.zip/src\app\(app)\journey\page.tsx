import { redirect } from 'next/navigation'

export default function JourneyRedirect() {
  redirect('/us')
}
